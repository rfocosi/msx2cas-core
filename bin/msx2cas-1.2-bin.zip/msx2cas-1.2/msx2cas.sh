#!/bin/sh
java -jar msx2cas.jar $*
